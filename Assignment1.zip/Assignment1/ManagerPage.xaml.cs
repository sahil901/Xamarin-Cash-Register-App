﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Assignment1.ProductFolder;

namespace Assignment1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ManagerPage : ContentPage
    {
        ProductChanges manager_prod = new ProductChanges();
        ManageProdHist manager_history = new ManageProdHist();

        public ManagerPage(ProductChanges pc, ManageProdHist mph)
        {
            InitializeComponent();

            manager_prod = pc;
            manager_history = mph;
        }

        async void RestockProducts(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new RestockPage(manager_prod));
        }

        async void PreviousPurchases(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new History(manager_history));
        }

        async void AddProducts(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new AddProdStock(manager_prod));
        }        
    }
}