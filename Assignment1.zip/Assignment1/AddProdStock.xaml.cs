﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment1.ProductFolder;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Assignment1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddProdStock : ContentPage
    {
        ProductChanges ProdList = new ProductChanges();

        public AddProdStock(ProductChanges p)
        {
            InitializeComponent();
            ProdList = p;
        }

        async public void AddStockForProduct(object sender, EventArgs e)
        {
            Product s = new Product(newProdName.Text, int.Parse(newProdQuantity.Text), double.Parse(newProdPrice.Text));
            ProdList.AddStock(s);
            await DisplayAlert("Done!", "New Product Added Sucessfully", "Done!");
            await Navigation.PopModalAsync();
        }

        async public void GoBack(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync(); 
        }
    }
}