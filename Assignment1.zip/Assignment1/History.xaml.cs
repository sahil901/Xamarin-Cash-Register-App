﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using Assignment1.ProductFolder;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Assignment1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class History : ContentPage
    {
        ManageProdHist historyofPurchase = new ManageProdHist();

        public History(ManageProdHist mph)
        {
            InitializeComponent();

            historyofPurchase = mph;

            BindingContext = historyofPurchase.prodhistory;

            PreviousView.ItemsSource = historyofPurchase.prodhistory;
        }

        async void PurchaseView(object sender, SelectedItemChangedEventArgs e)
        {
            ProductDetail s = e.SelectedItem as ProductDetail;

            await Navigation.PushModalAsync(new HistoryDetail(s));
        }
    }
}
