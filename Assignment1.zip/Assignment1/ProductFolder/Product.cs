﻿using System;
namespace Assignment1
{
    public class Product
    {
        public string name { get; set; }
        public int quantity { get; set; }
        public double price { get; set; }

        public Product() { }

        public Product(string name, int quantity, double price)
        {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }

        public override string ToString()
        {
            return this.name;
        }
    }
}