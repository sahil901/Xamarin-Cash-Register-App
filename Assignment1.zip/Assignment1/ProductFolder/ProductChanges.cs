﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace Assignment1.ProductFolder
{
    public class ProductChanges
    {
        public ObservableCollection<Product> AddProduct { get; set; }

        public ProductChanges()
        {
            AddProduct = new ObservableCollection<Product>();
            AddProduct.Add(new Product("Pants", 20, 50.70));
            AddProduct.Add(new Product("Shoes", 50, 90.00));
            AddProduct.Add(new Product("Hats", 10, 20.50));
            AddProduct.Add(new Product("Tshirts", 10, 31.00));
            AddProduct.Add(new Product("Dresses", 24, 64.00));
            AddProduct.Add(new Product("Socks", 50, 15.50));
        }

        public void AddStock(Product ats)
        {
            AddProduct.Add(ats);
        }
        public void UpdateStock(Product p, int s)
        {
            p.quantity = s;
        }

        public int GetStock(Product p)
        {
            return p.quantity;
        }
    }

    public class ManageProdHist
    {
        public ObservableCollection<ProductDetail> prodhistory = new ObservableCollection<ProductDetail>();
        public ManageProdHist() { }
    }
}
