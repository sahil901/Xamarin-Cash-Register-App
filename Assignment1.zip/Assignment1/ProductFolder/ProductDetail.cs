﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1
{
    public class ProductDetail : Product
    {
        public string DateOfPurchase { get; set; }
        public ProductDetail()
        {

        }

        public ProductDetail(string name, int quantity, double price) : base(name, quantity, price)
        {
            this.DateOfPurchase = DateTime.Now.ToString();
        }

        public override string ToString()
        {
            return "Item = =  = = = " + this.name + " " + this.quantity + " " + this.DateOfPurchase + " " + this.price;
        }
    }
}
