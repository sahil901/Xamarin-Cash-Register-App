﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using Assignment1.ProductFolder;

namespace Assignment1
{
    public partial class MainPage : ContentPage
    {
        public int Prod_Stock = 0;

        ProductChanges NewProduct = new ProductChanges();
        ManageProdHist ProductSold = new ManageProdHist();

        public MainPage()
        {
            InitializeComponent();
            BindingContext = NewProduct.AddProduct;
            list_product.ItemsSource = NewProduct.AddProduct;
            ProdQuant.Text = Prod_Stock.ToString();
        }
        private void Default()
        {
            Item.Text = "Type";
            ProdQuant.Text = "0";
            Total.Text = "Total";
        }

        public void NumberButton(object sender, EventArgs e)
        {
            Button num_butt = sender as Button;
            if (!ProdQuant.Text.Equals("0"))
            {
                ProdQuant.Text += num_butt.Text;
            }
            else
            {
                ProdQuant.Text = num_butt.Text;
            }

            foreach (Product s in NewProduct.AddProduct)
            {
                if (s.name.Equals(Item.Text))
                {
                    Total.Text = (s.price * Int32.Parse(ProdQuant.Text)).ToString();
                }
            }
        }

        void OnViewSelected(object sender, SelectedItemChangedEventArgs s)
        {
            Product selectedProduct = s.SelectedItem as Product;
            Item.Text = selectedProduct.name;

            if (!ProdQuant.Text.Equals("0")) Total.Text = (selectedProduct.price * Int32.Parse(ProdQuant.Text)).ToString();
        }

        async void goManagerPage(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new ManagerPage(NewProduct, ProductSold));
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            list_product.ItemsSource = null;
            list_product.ItemsSource = NewProduct.AddProduct;
        }

        public void Buy(object sender, EventArgs e)
        {
            int buy_product_quantity = Int32.Parse(ProdQuant.Text);

            var buy_selected_product = NewProduct.AddProduct.FirstOrDefault(item => item.name.Equals(Item.Text));

            int s = NewProduct.AddProduct.IndexOf(buy_selected_product);

            if (s < 0)
            {
                DisplayAlert("Error", "Please select an Item and provide quantity", "Ok");
            }

            else if (NewProduct.AddProduct[s].quantity >= buy_product_quantity)
            {
                Product new_purchased_product = new Product(NewProduct.AddProduct[s].name, NewProduct.AddProduct[s].quantity - buy_product_quantity, NewProduct.AddProduct[s].price);
                NewProduct.AddProduct[s] = new_purchased_product;

                ProductDetail new_Item = new ProductDetail(new_purchased_product.name, int.Parse(ProdQuant.Text), double.Parse(Total.Text));
                ProductSold.prodhistory.Add(new_Item);

                Default();
            }

            else if (buy_product_quantity > NewProduct.AddProduct[s].quantity)
            {
                DisplayAlert("Error", "Not enough in stock!", "Ok");
                Default();
            }
          
            else
            {
                DisplayAlert("Error", "Select a product from the list", "Ok");
                Default();
            }
        }
    }
}
