﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment1.ProductFolder;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Assignment1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RestockPage : ContentPage
    {
        ProductChanges restock_list = new ProductChanges();
        public RestockPage(ProductChanges s)
        {
            InitializeComponent();

            restock_list = s;

            BindingContext = restock_list.AddProduct;

            restocklistOfProducts.ItemsSource = restock_list.AddProduct;
        }

        async public void GoBack(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }

        public void SelectFromList(object sender, SelectedItemChangedEventArgs e)
        {
            Product productFromList = restocklistOfProducts.SelectedItem as Product;
        }

        public void RestockSelectedProduct(object sender, EventArgs e)
        {
            Product productToRestock = restocklistOfProducts.SelectedItem as Product;

            if (productToRestock == null)
            {
                DisplayAlert("Error", "You have to select an Item and provide a new quantity", "OK");
            }
            else
            {
                if ((restockedQuantity.Text == null || restockedQuantity.Text.Length == 0) || double.Parse(restockedQuantity.Text) < 0)
                {
                    DisplayAlert("Error", "Please provide a quantity", "OK");
                }

                else
                {
                    restock_list.UpdateStock(productToRestock, restock_list.GetStock(productToRestock) + int.Parse(restockedQuantity.Text));
                    restocklistOfProducts.ItemsSource = null;
                    restocklistOfProducts.ItemsSource = restock_list.AddProduct;

                    DisplayAlert("Success", "Quantity was updated", "OK");
                }
            }
        }
    }
}